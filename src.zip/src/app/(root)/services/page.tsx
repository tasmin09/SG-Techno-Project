import React from "react";
import Services from "@/components/Services";

const servicesPage = () => {
  return <Services />;
};

export default servicesPage;
