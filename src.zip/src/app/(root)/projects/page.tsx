import React from "react";
import Projects from "@/components/Projects";

const projectsPage = () => {
  return <Projects />;
};

export default projectsPage;
