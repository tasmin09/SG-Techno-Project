"use client";

import Image from "next/image";
import React, { useLayoutEffect } from "react";
import BG2 from "@/assets/images/bg2.jpg";
import styles from "./style.module.scss";
import doubleComma from "@/assets/texts/dbcomma.svg";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

function MissionSection(props: any) {
  useLayoutEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    gsap.context(() => {
      gsap.to(".missionImg", {
        scrollTrigger: {
          trigger: ".missionImg",
          scrub: 1,
          // markers: true,
          id: "missionImg",
          start: "top bottom",
          end: "top 85%",
        },
        duration: 2,
        y: `-=15dvh`,
      });
    }, props.sectionRef);
  }, []);

  return (
    <>
      <section
        ref={props.sectionRef}
        className={styles.missionSectionContainer}
      >
        <div className={styles.blueBackground}>
          <div>
            <Image
              className="missionImg"
              alt="img"
              src={BG2}
              width={500}
              height={650}
            />
          </div>
          <div>
            <h1
              data-aos="fade-up"
              data-aos-anchor-placement="bottom-bottom"
              data-aos-duration="2000"
            >
              Our Mission
            </h1>
            <article>
              <p
                data-aos="fade-up"
                data-aos-anchor-placement="center-bottom"
                data-aos-duration="2000"
              >
                Our mission is to provide top-quality heating ventilation and
                air conditioning services that meet our customer needs and
                exceed their expectations. We are dedicated to using the most
                advanced technology and innovative techniques to deliver
                efficient, reliable, and cost-effective solutions. Our team of
                highly trained and experienced professionals is committed to
                delivering the best customer service in the industry, ensuring
                complete satisfaction with every job we do. At SG Technofab, we
                strive to be the premier choice for all of our customers HVAC
                needs.
              </p>
            </article>

            <Image
              alt="img"
              src={doubleComma}
              height={220}
              width={220}
              className={styles.doubleComma}
            />
          </div>
        </div>
      </section>

      <section className={styles.missionMobileSectionContainer}>
        <h1
          data-aos="fade-up"
          data-aos-anchor-placement="bottom-bottom"
          data-aos-duration="2000"
        >
          Our Mission
        </h1>
        <Image alt="img" src={BG2} width={600} height={500} />
        <div className={styles.blueBackground}>
          <article>
            <p
              data-aos="fade-up"
              data-aos-anchor-placement="bottom-bottom"
              data-aos-duration="2000"
            >
              Our mission is to provide top-quality heating ventilation and air
              conditioning services that meet our customer needs and exceed
              their expectations. We are dedicated to using the most advanced
              technology and innovative techniques to deliver efficient,
              reliable, and cost-effective solutions. Our team of highly trained
              and experienced professionals is committed to delivering the best
              customer service in the industry, ensuring complete satisfaction
              with every job we do. At SG Technofab, we strive to be the premier
              choice for all of our customers HVAC needs.
            </p>
          </article>

          <Image
            alt="img"
            src={doubleComma}
            height={220}
            width={220}
            className={styles.doubleComma}
          />
        </div>
      </section>
    </>
  );
}

export default MissionSection;
